<?php
$conn = mysqli_connect("localhost", "root", "", "kampus");
if ($conn == true) {
    echo "berhasil terhubung ke database";
} else {
    echo "gagal terhubung ke database";
}